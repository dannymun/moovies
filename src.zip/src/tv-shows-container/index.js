import $ from 'jquery'

export default $('#app-body').find('.tv-shows')