import $ from 'jquery'
import page from 'page'
import { getShows } from 'src/tvmaze-api-client'
import renderShows from 'src/render'
import $tvShowContainer from 'src/tv-shows-container'

page('/', function(ctx, next) {
    if (!localStorage.shows) {
        getShows(function(shows) {
            $tvShowContainer.find('.loader').remove();
            localStorage.shows = JSON.stringify(shows);
            renderShow(shows);
        })
    } else {
        renderShow(JSON.parse(localStorage.shows));
    }
})

page()